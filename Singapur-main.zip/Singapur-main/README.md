# Proyecto: Singapur: Una Mirada Profunda

Este es un proyecto de página web interactiva sobre Singapur, construida con React y Vite, utilizando Tailwind CSS para los estilos. La información se basa en el documento "Singapur: Una Mirada Profunda".

## Estructura del Proyecto

El proyecto sigue una estructura modular para facilitar la organización y escalabilidad: